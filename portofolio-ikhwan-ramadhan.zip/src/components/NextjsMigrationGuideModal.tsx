import React, { useState } from 'react';
import { 
  X, 
  Code2, 
  Copy, 
  Check, 
  Sparkles
} from 'lucide-react';

interface NextjsMigrationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NextjsMigrationGuideModal: React.FC<NextjsMigrationGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const steps = [
    {
      title: '01 // DEPLOY TO GITHUB PAGES (REACT SPA SPEED)',
      desc: 'This project builds directly into static HTML/JS assets ready for GitHub Pages hosting.',
      code: `# 1. Install gh-pages
npm install --save-dev gh-pages

# 2. Add deploy script in package.json:
# "deploy": "vite build && gh-pages -d dist"

# 3. Trigger build & push to your GitHub repository:
npm run deploy`
    },
    {
      title: '02 // MIGRATE TO NEXT.JS 14 APP ROUTER + UNOCSS',
      desc: 'Enable React Server Components (RSC) and fast Edge SSG for Markdown documentation:',
      code: `# 1. Initialize Next.js App
npx create-next-app@latest my-portfolio --typescript --eslint --app

# 2. Install UnoCSS packages
npm install -D unocss @unocss/postcss @unocss/preset-uno @unocss/preset-attributify

# 3. Create uno.config.ts in the root directory`
    },
    {
      title: '03 // RECOMMENDED UNO.CONFIG.TS CONFIGURATION',
      desc: 'Optimized Atomic CSS preset for zero runtime overhead:',
      code: `// uno.config.ts
import { defineConfig, presetUno, presetAttributify } from 'unocss';

export default defineConfig({
  presets: [
    presetUno(),
    presetAttributify(),
  ],
  theme: {
    fontFamily: {
      sans: 'Space Grotesk, sans-serif',
      mono: 'Space Mono, monospace',
    },
  },
});`
    },
    {
      title: '04 // PARSING MARKDOWN IN NEXT.JS APP ROUTER',
      desc: 'Read local filesystem markdown with gray-matter and react-markdown:',
      code: `// app/portofolio/[slug]/page.tsx
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export async function generateStaticParams() {
  const files = fs.readdirSync(path.join(process.cwd(), 'content/projects'));
  return files.map((filename) => ({
    slug: filename.replace('.md', ''),
  }));
}

export default async function ProjectPage({ params }: { params: { slug: string } }) {
  const markdownWithMeta = fs.readFileSync(
    path.join(process.cwd(), 'content/projects', \`\${params.slug}.md\`),
    'utf-8'
  );
  const { data: frontmatter, content } = matter(markdownWithMeta);

  return (
    <article className="prose dark:prose-invert max-w-4xl mx-auto py-10">
      <h1>{frontmatter.title}</h1>
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
    </article>
  );
}`
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs animate-in fade-in duration-150 font-sans">
      <div 
        className="relative w-full max-w-3xl max-h-[92vh] flex flex-col bg-white dark:bg-[#0a0a0a] border border-black/10 dark:border-white/10 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 border border-black/20 dark:border-white/20 text-black dark:text-white flex items-center justify-center font-bold">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-slate-400 dark:text-white/40">
                ARCHITECTURE //
              </div>
              <h2 className="font-black font-display text-base sm:text-lg text-slate-950 dark:text-white uppercase tracking-tight">
                DEPLOYMENT & NEXT.JS + UNOCSS MIGRATION
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 border border-black/10 dark:border-white/10 hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-8 space-y-6 text-xs sm:text-sm">
          
          <div className="p-4 bg-black/[0.02] dark:bg-white/[0.02] border border-black/10 dark:border-white/10 space-y-1 font-mono">
            <h3 className="font-bold flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-950 dark:text-white">
              <Sparkles className="w-3.5 h-3.5" />
              <span>PORTABLE & CLEAN DATA ARCHITECTURE</span>
            </h3>
            <p className="text-xs text-slate-600 dark:text-white/60 leading-relaxed font-sans font-light">
              This portfolio codebase is structured with strict TypeScript schemas and standard Markdown formatting, allowing direct build as a Vite SPA on GitHub Pages or seamless export to Next.js 14 App Router without altering data files.
            </p>
          </div>

          <div className="space-y-6 font-mono">
            {steps.map((step, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between border-b border-black/10 dark:border-white/10 pb-1">
                  <h3 className="font-bold text-slate-950 dark:text-white text-xs uppercase tracking-wider">
                    {step.title}
                  </h3>
                  <button
                    onClick={() => handleCopy(step.code, idx)}
                    className="flex items-center gap-1 px-2.5 py-1 border border-black/20 dark:border-white/20 text-slate-900 dark:text-white hover:bg-black hover:text-white dark:hover:bg-white dark:hover:text-black text-[10px] uppercase tracking-wider transition-all"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-500" />
                        <span>COPIED</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>COPY CODE</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-600 dark:text-white/60 font-sans font-light">
                  {step.desc}
                </p>

                <pre className="p-3.5 bg-[#050505] text-slate-200 font-mono text-[11px] overflow-x-auto leading-relaxed border border-white/10">
                  <code>{step.code}</code>
                </pre>
              </div>
            ))}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-black/[0.02] dark:bg-white/[0.02] border-t border-black/10 dark:border-white/10 flex justify-end font-mono">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-black text-white dark:bg-white dark:text-black text-xs font-bold uppercase tracking-widest hover:opacity-85 transition-all"
          >
            [ CLOSE GUIDE ]
          </button>
        </div>

      </div>
    </div>
  );
};
